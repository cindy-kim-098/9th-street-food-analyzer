/**
 * Used to show how records work with Json file
 * @author Owen Astrachan
 */
public record Restaurant(String name, String address, String cuisine) {
    
}
